
// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyD-UyeZaHdO45-KnmkfVCPDd8LdF7cpONw",
  authDomain: "movies-efce1.firebaseapp.com",
  databaseURL: "https://movies-efce1.firebaseio.com",
  projectId: "movies-efce1",
  storageBucket: "movies-efce1.appspot.com",
  messagingSenderId: "829108348467",
  appId: "1:829108348467:web:1e074865201f2b82446546",
  measurementId: "G-5GJCE7PR4M"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);



