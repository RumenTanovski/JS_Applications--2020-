import {
    registerUser,
    login,
    logout,
} from './models/user.js';

import {
    create,
    getAll
} from './models/movies.js';



const app = Sammy("body", function () {
    this.use("Handlebars", "hbs");

    this.get('#/home', function (ctx) {
        
        setHeader(ctx);
        getAll()
        .then(res => {
            console.log(res.docs[0].data());
            const movies = res.docs.map(x => x = {
                ...x.data(),
                id: x.id
            });
            console.log(movies);
        });
        
        ctx.loadPartials(commonPartial).partial('./view/home.hbs');
    });


    // this.get('#/profile', function (ctx) {
    //     ctx.loadPartials(commonPartial).partial('./view/user/profile.hbs');
    // });

    this.get('#/register', function (ctx) {
        ctx.loadPartials(commonPartial).partial('./view/user/register.hbs');
    });

    this.post('#/register', function (ctx) {
        const {
            email,
            password,
            repeatPassword
        } = ctx.params;
        if (password !== repeatPassword) {
            throw new Error('Password do not match!');
        }
        registerUser(email, password)
            .then(res => {
                saveUserInfo(res.user.email);
                ctx.redirect('#/home');
            })
            .catch(e => console.log(e));
    });

    this.get('#/login', function (ctx) {
        ctx.loadPartials(commonPartial).partial('./view/user/login.hbs');
    });

    this.post('#/login', function (ctx) {
        const {
            email,
            password
        } = ctx.params;
        login(email, password)
            .then(res => {
                saveUserInfo(res.user.email);
                console.log(res.user.email);
                ctx.redirect('#/home');
            }).catch(e => console.log(e));
    });

    this.get('#/logout', function (ctx) {
        sessionStorage.clear();
        console.log(ctx.isAuth);
        logout()
            .then(() => {
                ctx.redirect('#/login');
            }).catch(e => console.log(e));
    });

    this.get('#/addmovie', function (ctx) {
        ctx.loadPartials(commonPartial).partial('./view/movies/create.hbs');
    });

    this.post('#/addmovie', function (ctx) {
        const {
            title,
            description,
            imageUrl
        } = ctx.params;
        create({
                title,                
                description,
                imageUrl
            })
            .then(res => {
                console.log(res);
                ctx.redirect('#/home');
            }).catch(e => console.log(e));
    });



    function saveUserInfo(userInfo) {
        sessionStorage.setItem('user', userInfo);
    }

    function setHeader(ctx) {
        ctx.isAuth = sessionStorage.getItem('user');
        ctx.user = sessionStorage.getItem('user');
    }

    const commonPartial = {
        header: './view/common/header.hbs',
        footer: './view/common/footer.hbs',
        movies: './view/movies/movies.hbs'
    };

});


app.run('#/home');