
// Your web app's Firebase configuration
// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyCzjmxcnxCnRqjS9n_SjY6ZAHw4_jpo6XM",
  authDomain: "shoes-7ee3a.firebaseapp.com",
  databaseURL: "https://shoes-7ee3a.firebaseio.com",
  projectId: "shoes-7ee3a",
  storageBucket: "shoes-7ee3a.appspot.com",
  messagingSenderId: "529522355230",
  appId: "1:529522355230:web:f1093c07cd4f97dfbad20f",
  measurementId: "G-JY40G6J2HV"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

